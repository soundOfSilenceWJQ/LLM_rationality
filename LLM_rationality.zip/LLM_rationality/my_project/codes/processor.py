import json
import multiprocessing
import random
import time
from http import HTTPStatus
import openai
import requests

REQUEST_TIME_LIMIT = 60

class BaseProcessor:
    def __init__(self, model_config):
        self.lock = multiprocessing.Lock()
        self.model_config = model_config

    def write_to_json(self, data, file_path):
        with self.lock:
            with open(file_path, 'a', encoding='utf-8') as file:
                json.dump(data, file, ensure_ascii=False)
                file.write('\n')

    def start_multi_thread(self, content, file_path):
        raise NotImplementedError("Subclasses must implement start_multi_thread method")


class GPTProcessor():
    def __init__(self, model_config):
        import openai
        self.lock = multiprocessing.Lock()
        self.model_config = model_config
        openai.api_key = model_config.api_key
        openai.api_base = model_config.api_url

    def write_to_json(self, data, file_path):
        with self.lock:
            with open(file_path, 'a', encoding='utf-8') as file:
                json.dump(data, file, ensure_ascii=False)
                file.write('\n')

    def start_multi_thread(self, content, file_path, save_result):
        status = 1
        while True:
            try:
                chat_completion = openai.ChatCompletion.create(model=self.model_config.model,
                                                               temperature=self.model_config.temperature,
                                                                max_tokens=self.model_config.max_tokens,
                                                                # frequency_penalty=self.model_config.frequency_penalty,
                                                               messages=[{"role": "user", "content": content}])

                answer = chat_completion.choices[0].message.content
                break
            except Exception as e:
                print(e)
                time.sleep(random.randint(1, 3))
        if save_result:
            self.write_to_json(answer, file_path)
        else:
            print(answer)
        time.sleep(random.randint(1, 3))
        return status


class QwenProcessor(BaseProcessor):
    def start_multi_thread(self, content, file_path, save_result):
        start_time = time.time()
        status = 1
        while True:
            try:
                import dashscope
                messages = [{'role': 'user', 'content': content}]
                response = dashscope.Generation.call(
                    model=self.model_config.model,
                    messages=messages,
                    result_format='message',
                    api_key=self.model_config.api_key,
                    temperature=self.model_config.temperature,
                    # repitition_penalty=self.model_config.penalty_score,
                    max_tokens=self.model_config.max_tokens,
                    enable_search=False
                )
                if response.status_code == HTTPStatus.OK:
                    answer = response.output.choices[0].message.content
                    if save_result:
                        self.write_to_json(answer, file_path)
                    else:
                        print(answer)
                    time.sleep(random.randint(5, 10))
                    break
                else:
                    print('Request id: %s, Status code: %s, error code: %s, error message: %s' % (
                        response.request_id, response.status_code,
                        response.code, response.message
                    ))
                    time.sleep(random.randint(5, 10))
            except Exception as e:
                time.sleep(random.randint(5, 10))
                if time.time() - start_time > REQUEST_TIME_LIMIT:
                    print('Request timeout')
                    status = 0
                    break

        return status


class ErnieProcessor(BaseProcessor):
    def start_multi_thread(self, content, file_path, save_result):
        start_time = time.time()
        status = 1
        while True:
            try:
                messages = json.dumps({
                    "messages": [
                        {
                            "role": "user",
                            "content": content
                        }
                    ],
                    "temperature": self.model_config.temperature,
                    # "penalty_score": self.model_config.penalty_score,
                    "max_output_tokens": self.model_config.max_tokens, 
                    # "system": "你需要作为一个代理人，尽可能回答我的问题。"
                })
                headers = {
                    'Content-Type': 'application/json'
                }
                response = requests.request(
                    "POST", self.model_config.url, headers=headers, data=messages)

                if response.status_code == HTTPStatus.OK:
                    answer = response.json()['result']
                    if save_result:
                        self.write_to_json(answer, file_path)
                    else:
                        print(answer)
                    break
                else:
                    print('Request id: %s, Status code: %s, error code: %s, error message: %s' % (
                        response.request_id, response.status_code,
                        response.code, response.message
                    ))
                    time.sleep(random.randint(1, 3))
            except Exception as e:
                print(e)
                time.sleep(random.randint(1, 3))
                if time.time() - start_time > REQUEST_TIME_LIMIT:
                    print('Request timeout')
                    status = 0
                    break
                # break

        
        time.sleep(random.randint(1, 3))
        return status
