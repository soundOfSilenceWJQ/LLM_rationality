# 给GPT的配置
import json

import requests


class modelConfigGPT:
    model = "gpt-4"
    temperature = 1
    api_key = "sk-W4wBqHlnuqSW8G4E3d92190c4846421eB3C2Fd3c5a533e94"
    api_url = "https://one-api.glm.ai/v1"
    max_tokens = 1000
    frequency_penalty = 1

    def __init__(self, model) -> None:
        self.model = model


# 给qwen的配置
class modelConfigQwen:
    model = "qwen-plus"  # qwen-turbo, qwen-plus, qwen-max, chatglm3-6b
    temperature = 0.85
    api_key = "sk-414cfa866cfb4e549e8190a36a92ccd8"
    # penalty_score = 1.5
    max_tokens = 1000

    def __init__(self, model) -> None:
        self.model = model


# 给ERNIE的配置
class modelConfigErnie:
    def get_access_token(self, client_id, client_secret):
        """
        使用 API Key，Secret Key 获取access_token，替换下列示例中的应用API Key、应用Secret Key
        """
            
        url = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}".format(client_id=client_id, client_secret=client_secret)
        
        payload = json.dumps("")
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    
        response = requests.request("POST", url, headers=headers, data=payload)
        return response.json().get("access_token")
    
    # model = ""  # ernie-3.5-8k-0205, ERNIE-4.0-8K(要另外开通，有点贵), ernie-char-8k, gemma_7b_it, yi_34b_chat, llama_2_7b, llama_2_13b, llama_2_70b, llama_3_8b, llama_3_70b, chatglm2_6b_32k, aquilachat_7b, xuanyuan_70b_chat
    client_id = "FL4FRMe4IyRBE0BACyyFd1Ur"
    client_secret = "3jeQMIUB2ubwJuUc0lvxFobG13KMTDG6"
    temperature = 0.8
    # penalty_score = 2
    max_tokens = 1000

    
    def __init__(self, model) -> None:
        self.model = model
        url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/" + model + "?access_token=" \
            + self.get_access_token(self.client_id, self.client_secret)
        self.url = url


class testConfig:
    language = "zh"
    test_times = 10
    prefix_num = -1
    suffix_num = -1
    # save_dir = "E:\Learning\ThisTerm\GraduationProject\my_project\\results\\prisoner_dilemma2\\"     # 保存结果的文件夹
    # save_dir = "E:\Learning\ThisTerm\GraduationProject\my_project\\results\\reasons\\banker2\\"
    save_dir = "E:\Learning\ThisTerm\GraduationProject\my_project\\results2\\test1\\"
    prompt_repo_path = "E:\Learning\ThisTerm\GraduationProject\my_project\prompt_repo2\\"

    def __init__(self) -> None:
        import os
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)

