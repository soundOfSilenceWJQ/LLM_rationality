import re
import pandas as pd

def find_max_value_coordinates(matrix):
    if not matrix or not matrix[0]:  # 如果矩阵为空或不包含任何元素
        return None

    max_value = matrix[0][0]  # 假设第一个元素是最大值
    max_coordinates = (0, 0)  # 初始化最大值的坐标为(0,0)

    for row_index, row in enumerate(matrix):  # 遍历行
        for col_index, value in enumerate(row):  # 遍历列
            if value > max_value:  # 如果发现更大的值
                max_value = value  # 更新最大值
                max_coordinates = (row_index, col_index)  # 更新最大值的坐标

    return max_value, max_coordinates[0], max_coordinates[1]


def get_answer_df(file_path, row_or_col):
    """从文本文件中提取答案记录，转换成pandas dataframe，这里读取方式可自行修改"""
    with open(file_path, 'r') as file:
        lines = file.readlines()

    df = pd.DataFrame(columns=['second_order_belief',
                      'first_order_belief', 'own choice'])
    # 从第二行开始读
    for i in range(1, len(lines)):
        line = lines[i]
        line = line[1:-2]
        choices = ['', '', '']
        if row_or_col:
            # choices[0]是第一个大写字母，choices[1]是第一个小写字母，choices[2]是第二个大写字母
            first_upper = re.search('[A-D]', line)
            if first_upper:
                first_lower = re.search('[a-d]', line[first_upper.end():])
                if first_lower:
                    second_upper = re.search('[A-D]', line[first_lower.end():])
                    if second_upper:
                        choices[0] = first_upper.group()
                        choices[1] = first_lower.group()
                        choices[2] = second_upper.group()
                        df.loc[len(df)] = choices
        else:
            # choices[0]是第一个小写字母，choices[1]是第一个大写字母，choices[2]是第二个小写字母
            first_lower = re.search('[a-d]', line)
            if first_lower:
                first_upper = re.search('[A-D]', line[first_lower.end():])
                if first_upper:
                    second_lower = re.search('[a-d]', line[first_upper.end():])
                    if second_lower:
                        choices[0] = first_lower.group()
                        choices[1] = first_upper.group()
                        choices[2] = second_lower.group()
                        df.loc[len(df)] = choices
    loss_rate = 1 - len(df) / (len(lines) - 1)
    return df, loss_rate


def get_answer_df_v2(file_path, row_or_col=True):
    """从文本文件中提取答案记录，转换成pandas dataframe"""
    with open(file_path, 'r') as file:
        lines = file.readlines()

    df = pd.DataFrame(columns=['second_order_belief',
                      'first_order_belief', 'own choice'])
    # 从第二行开始读
    for i in range(1, len(lines)):
        line = lines[i]
        # 去除开头和结尾的引号
        line = line[1:-2]
        choices = ['', '', '']
        for i in range(0, len(line)):
            valid = 1
            if line[i] == '2' and line[i + 1] == '.':
                # 向前找最后一个字母
                j = i - 1
                while line[j] != 'A' and line[j] != 'B' and line[j] != 'C' and line[j] != 'D' and line[j] != 'a' and line[j] != 'b' and line[j] != 'c' and line[j] != 'd':
                    j -= 1
                    if line[j] == '1' and line[j + 1] == '.':
                        valid = 0
                        break
                choices[0] = line[j]
            if line[i] == '3' and line[i + 1] == '.':
                # 向前找最后一个字母
                j = i - 1
                while line[j] != 'A' and line[j] != 'B' and line[j] != 'C' and line[j] != 'D' and line[j] != 'a' and line[j] != 'b' and line[j] != 'c' and line[j] != 'd':
                    j -= 1
                    if line[j] == '2' and line[j + 1] == '.' or j < 0:
                        valid = 0
                        break
                choices[1] = line[j]
            if i == len(line) - 1:
                j = i
                while line[j] != 'A' and line[j] != 'B' and line[j] != 'C' and line[j] != 'D' and line[j] != 'a' and line[j] != 'b' and line[j] != 'c' and line[j] != 'd':
                    j -= 1
                    if line[j] == '3' and line[j + 1] == '.':
                        valid = 0
                        break
                choices[2] = line[j]
            if valid == 1:
                if row_or_col:
                    if choices[0] >= 'a' and choices[0] <= 'd':
                        choices[0] = chr(ord(choices[0]) - ord('a') + ord('A'))
                    if choices[1] >= 'A' and choices[1] <= 'D':
                        choices[1] = chr(ord(choices[1]) - ord('A') + ord('a'))
                    if choices[2] >= 'a' and choices[2] <= 'd':
                        choices[2] = chr(ord(choices[2]) - ord('a') + ord('A'))
                else:
                    if choices[0] >= 'A' and choices[0] <= 'D':
                        choices[0] = chr(ord(choices[0]) - ord('A') + ord('a'))
                    if choices[1] >= 'a' and choices[1] <= 'd':
                        choices[1] = chr(ord(choices[1]) - ord('a') + ord('A'))
                    if choices[2] >= 'A' and choices[2] <= 'D':
                        choices[2] = chr(ord(choices[2]) - ord('A') + ord('a'))
                df.loc[len(df)] = choices
    return df


def get_choice_count(df, choice_row, choice_col, row_or_col):
    """计算答案记录df中某个选择的次数（oc, fob, sob）"""
    oc_choice_cnt = 0
    fob_choice_cnt = 0
    sob_choice_cnt = 0
    total_cnt = 0
    for i in range(len(df)):
        row = df.iloc[i]
        oc = row['own choice']
        fob = row['first_order_belief']
        sob = row['second_order_belief']
        if row_or_col:
            if oc == choice_row:
                oc_choice_cnt += 1
            if fob == choice_col:
                fob_choice_cnt += 1
            if sob == choice_row:
                sob_choice_cnt += 1
        else:
            if oc == choice_col:
                oc_choice_cnt += 1
            if fob == choice_row:
                fob_choice_cnt += 1
            if sob == choice_col:
                sob_choice_cnt += 1
        total_cnt += 1
    return oc_choice_cnt, fob_choice_cnt, sob_choice_cnt, total_cnt


def get_all_choice_cnt(df, row_or_col, total_choice_num):
    cnt = []
    for i in range(0, total_choice_num):
        cnt.append(0)
    for i in range(len(df)):
        row = df.iloc[i]
        if row_or_col:
            cnt[ord(row['own choice']) - ord('A')] += 1
        else:
            cnt[ord(row['own choice']) - ord('a')] += 1
    return cnt


def get_fo_consistency(df, payoff_matrix, row_or_col):
    '''计算一个玩家在一个game中满足一阶一致性的选择次数。
    df是答案记录的dataframe，payoff_matrix是行玩家或列玩家的收益矩阵，
    row_or_col表示玩家是行玩家(True)还是列玩家(False)'''
    consist_cnt = 0
    total_cnt = 0
    for i in range(len(df)):
        # 从df中取出一行，计算一致性
        row = df.iloc[i]
        oc = row['own choice']
        fob = row['first_order_belief']

        # 确定对方选择fb的情况下，其所有选择对应的收益
        contigent_payoff_list = []
        if row_or_col:
            for j in range(0, len(payoff_matrix)):
                contigent_payoff_list.append(
                    payoff_matrix[j][ord(fob) - ord('a')])
            payoff_achieved = contigent_payoff_list[ord(oc) - ord('A')]
            # 若自己的选择对应的收益不是最大的，说明自己的选择不一致
            if payoff_achieved == max(contigent_payoff_list):
                consist_cnt += 1
            total_cnt += 1
        else:
            for j in range(len(payoff_matrix[0])):
                contigent_payoff_list.append(
                    payoff_matrix[ord(fob) - ord('A')][j])
            payoff_achieved = contigent_payoff_list[ord(oc) - ord('a')]
            if payoff_achieved == max(contigent_payoff_list):
                consist_cnt += 1
            total_cnt += 1
    return consist_cnt, total_cnt


def get_so_consistency(df, payoff_matrix, row_or_col):
    '''计算一个玩家在一个game中满足二阶一致性的选择次数。
    df是答案记录的dataframe，payoff_matrix是行玩家或列玩家的收益矩阵，
    row_or_col表示玩家是行玩家(True)还是列玩家(False)'''
    consist_cnt = 0
    total_cnt = 0
    for i in range(len(df)):
        # 从df中取出一行，计算一致性
        row = df.iloc[i]
        fob = row['first_order_belief']
        sob = row['second_order_belief']
        # 确定自己选择sb的情况下，对方所有选择对应的收益
        contigent_payoff_list = []
        if row_or_col:
            for j in range(len(payoff_matrix[0])):
                contigent_payoff_list.append(
                    payoff_matrix[ord(sob) - ord('A')][j])
            payoff_achieved = contigent_payoff_list[ord(fob) - ord('a')]
            # 若fo对应的选择对应的收益不是最大的，说明不一致
            if payoff_achieved == max(contigent_payoff_list):
                consist_cnt += 1
            total_cnt += 1
        else:
            for j in range(len(payoff_matrix)):
                contigent_payoff_list.append(
                    payoff_matrix[j][ord(sob) - ord('a')])
            payoff_achieved = contigent_payoff_list[ord(fob) - ord('A')]
            if payoff_achieved == max(contigent_payoff_list):
                consist_cnt += 1
            total_cnt += 1
    return consist_cnt, total_cnt


def get_nash_consistency(df, row_or_col, nash_row, nash_col):
    '''计算一个玩家在一个game中满足纳什均衡一致性的选择次数。
    df是答案记录的dataframe，payoff_matrix是行玩家或列玩家的收益矩阵，
    row_or_col表示玩家是行玩家(True)还是列玩家(False)'''
    
    consist_cnt = 0
    total_cnt = 0
    for i in range(len(df)):
        # 从df中取出一行，计算一致性
        row = df.iloc[i]
        oc = row['own choice']
        fob = row['first_order_belief']
        # 确定对方选择fb的情况下，其所有选择对应的收益
        if row_or_col:
            if oc == nash_row and fob == nash_col:
                consist_cnt += 1
            total_cnt += 1
        else:
            if oc == nash_row and fob == nash_col:
                consist_cnt += 1
            total_cnt += 1
    return consist_cnt, total_cnt


def get_max_consistency(df, payoff_matrix, row_or_col):
    '''计算一个玩家在一个game中满足最大化一致性的选择次数。
    df是答案记录的dataframe，payoff_matrix是行玩家或列玩家的收益矩阵，
    row_or_col表示玩家是行玩家(True)还是列玩家(False)'''
    
    consist_cnt = 0
    total_cnt = 0
    for i in range(len(df)):
        # 从df中取出一行，计算一致性
        row = df.iloc[i]
        oc = row['own choice']
        fob = row['first_order_belief']
        # 得到payoff_matrix中对应的最大收益对应的行和列
        max_value, max_row, max_col = find_max_value_coordinates(payoff_matrix)

        if row_or_col:
            if ord(oc) - ord('A') == max_row and ord(fob) - ord('a') == max_col:
                consist_cnt += 1
            total_cnt += 1
        else:
            if ord(oc) - ord('a') == max_col and ord(fob) - ord('A') == max_row:
                consist_cnt += 1
            total_cnt += 1
    return consist_cnt, total_cnt