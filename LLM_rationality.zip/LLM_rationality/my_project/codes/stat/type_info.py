class game:
    row_type_list = []
    col_type_list = []

    def __init__(self, row_type_list, col_type_list):
        self.row_type_list = row_type_list
        self.col_type_list = col_type_list

game_list = []
game_list.append(game([['D1', 'D2', 'E', 'S'], ['A', 'P', 'O']], 
                      [['E'], ['A']]))
game_list.append(game([['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E']], 
                      [['D2', 'E'], ['A'], ['P', 'O', 'D1', 'D2', 'S']]))
game_list.append(game([['A'], ['E']], 
                      [['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']]))
game_list.append(game([['A', 'P'], ['E'], ['O', 'D1', 'D2', 'L2', 'S']], 
                      [['L2', 'E', 'S'], ['A', 'P', 'O', 'D1', 'D2']]))
game_list.append(game([['E'], ['A', 'P'], ['O', 'D1', 'D2','L2', 'S']], 
                      [['L2', 'E', 'S'], ['A', 'P', 'O', 'D1', 'D2']]))
game_list.append(game([['A'], ['P', 'O', 'D1', 'L2', 'S'], ['D2', 'E']], 
                      [['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E']]))
game_list.append(game([['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']], 
                      [[], ['E'], ['A']]))
game_list.append(game([['L2', 'E'], ['A', 'P', 'O', 'D1', 'D2']], 
                      [['O', 'D1', 'D2', 'L2', 'S'], ['A', 'P'], ['E']]))
game_list.append(game([[], ['A'], ['E']], 
                      [['D1', 'D2', 'L2', 'E', 'S'], ['A', 'P', 'O']]))
game_list.append(game([['A', 'P', 'O', 'D1', 'D2'], ['L2', 'E']], 
                      [['O', 'D1', 'D2', 'L2', 'S'], ['A', 'P'], ['E']]))
game_list.append(game([['D1', 'D2', 'L2', 'E', 'S'], ['P'], ['A', 'O']], 
                      [['A'], ['E']]))
game_list.append(game([['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']], 
                      [['E'], ['A']]))
game_list.append(game([['E'], ['A']], 
                      [['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']]))
game_list.append(game([['D1', 'D2', 'L2', 'E', 'S'], ['A', 'P', 'O']], 
                      [['A'], ['D2', 'E'], ['P', 'O', 'D1', 'D2', 'S']]))
game_list.append(game([['A'], ['D2', 'E'], ['P', 'O', 'D1', 'L2', 'S']], 
                      [['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']]))
game_list.append(game([['E'], ['A']], 
                      [['D1', 'D2', 'L2', 'E'], ['P'], ['A', 'O', 'S']]))
game_list.append(game([[], [], ['A'], ['E']], 
                      [['D1', 'D2', 'L2', 'E', 'S'], ['A', 'P', 'O']]))
game_list.append(game([['A', 'P', 'O'], ['D1', 'D2', 'L2', 'E', 'S']], 
                      [[], [], ['A'], ['E']]))