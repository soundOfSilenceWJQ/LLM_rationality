# dictator game部分，统计每个文件中测试者做出的选择
import re
import os
from matplotlib import pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd
import sys
sys.path.append("E:\Learning\ThisTerm\GraduationProject\my_project\codes\\")
from utils import traverse_folder

def find_last_number(s):  
    match = re.search(r'\d+(\D*$)', s)  # \d+ 匹配一个或多个数字，\D*$ 确保后面没有数字  
    if match:  
        return match.group(0).rstrip('\D')  # 去除可能存在的非数字字符  
    else:  
        return None  # 如果没有找到数字，返回None  
    

def get_array(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    # 提取每一行中的数字
    array = []
    for i in range(1, len(lines)):
        line = lines[i]
        line_nums = []
        num = re.search(r'\d+', line)
        if num:
            line_nums.append(int(num.group()))
        if len(line_nums) > 0:
            if len(line_nums) == 1:
                if line_nums[0] <= 100:
                    array = array + line_nums
            # 如果既有100又有小于100的数字，只取小于100的数字
            elif 100 in line_nums and min(line_nums) < 100:
                line_nums.remove(100)
                array = array + line_nums
    return array, 1 - len(array)/(len(lines) - 1)


def get_array_2(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    # 提取每一行中的数字
    array = []
    for i in range(1, len(lines)):
        line = lines[i]
        num = find_last_number(line)
        if num:
            array.append(int(num))
    return array, 1 - len(array)/(len(lines) - 1)


def get_histo_array(array):
    histo_array = []
    if len(array) != 0:
        for i in range(0, max(array) + 1):
            if array.count(i) != 0:
                histo_array.append(array.count(i))
        histo_array = [x / sum(histo_array) for x in histo_array]
    array = list(set(array))
    array.sort()
    return array, histo_array


# def get_array_from_dir(dir_path):
#     file_list = traverse_folder(dir_path)
#     array = []
#     for file_path in file_list:
#         array.append(get_array(file_path))
#     return array


def draw_histogram(x, y, x_label, y_label, title, save_dir):
    plt.bar(x, y, color='b', width=1.2)
    # 颜色统一
    plt.rcParams['axes.prop_cycle'] = plt.cycler(color=plt.cm.tab20.colors)
    plt.xlabel(x_label, fontsize=18)
    plt.ylabel(y_label, fontsize=18)
    plt.title(title, fontsize=20)
    # 横坐标刻度为10
    plt.xticks(range(0, 101, 10))
    # 纵坐标用百分比表示
    plt.gca().yaxis.set_major_formatter(PercentFormatter(1))
    # 横坐标范围0-100
    plt.xlim(0, 100)
    # plt.show()
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    # 保存图片
    # if not os.path.exists(save_dir + title + ".png"):
    plt.savefig(save_dir + title + ".png")
    plt.clf()
    

def stat_dictator(dir_path, fig_save_path, csv_save_path, init_point=0, step=1):    
    file_list= traverse_folder(dir_path)
    sub_list = os.listdir(dir_path)
    stat_df = pd.DataFrame()
    for i in range(init_point, len(file_list), step):
        file_path = file_list[i]
        sub_path = sub_list[int(i/step)]
        model_name = sub_path
        array, loss_rate = get_array_2(file_path)
        print(array)
        if len(array) != 0:
            mean = np.mean(array)
            std = np.std(array)
            # 保留三位小数
            mean = round(mean, 3)
            std = round(std, 3)
            loss_rate = round(loss_rate, 3)
        else:
            mean = pd.NA
            std = pd.NA
            loss_rate = 1
        print(f"model_name: {model_name}, mean: {mean}, std: {std}, loss_rate: {loss_rate}")
        stat_df.loc[i] = [model_name, mean, std, loss_rate]
        # print(array)
        x, y = get_histo_array(array)
        draw_histogram(x, y, "The value LLM is willing to pay back", "Percentage", model_name, fig_save_path)
    stat_df.to_csv(csv_save_path, index=False)


def get_accept_rate(file_path):
    # 统计文件中选择“是”的频率
    with open(file_path, 'r') as file:
        lines = file.readlines()
    accept_num = 0
    reject_num = 0
    for i in range(1, len(lines)):
        line = lines[i]
        if "是" in line:
            accept_num += 1
        if "否" in line:
            reject_num += 1
    accept_rate = accept_num / (len(lines) - 1)
    loss_rate = (accept_num + reject_num) / (len(lines) - 1)
    return accept_rate, loss_rate


def stat_accept_rate(dir_path, csv_save_path):
    file_list = traverse_folder(dir_path)
    sub_list = os.listdir(dir_path)
    stat_df = pd.DataFrame()
    for i in range(len(file_list)):
        file_path = file_list[i]
        sub_path = sub_list[i]
        model_name = sub_path
        accept_rate, loss_rate = get_accept_rate(file_path)
        stat_df.loc[i] = [model_name, accept_rate, loss_rate]
    stat_df.to_csv(csv_save_path, index=False)


if __name__ == '__main__':
    stat_dictator(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\banker\\",
                  r"E:\Learning\ThisTerm\GraduationProject\my_project\results\histogram\\banker2\\",
                  r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics_summary\banker2.csv", 1, 2)
    # stat_accept_rate(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\test_results9\\", 
    #                  r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics_summary\dictator6.csv")
