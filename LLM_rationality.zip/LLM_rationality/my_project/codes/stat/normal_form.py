import os
import numpy as np
import pandas as pd
from payoff_matrix import cpp
from payoff_matrix import rpp
import game_info_list
import type_info
from normal_form_utils import get_answer_df, get_choice_count, get_fo_consistency, \
    get_so_consistency, get_max_consistency, get_nash_consistency, get_all_choice_cnt


def get_loss_rate(game_num_list, model_name, src_dir):
    '''统计每个game的缺失率，返回一个DataFrame，包含MODEL_NAME, game_num, row_loss_rate, col_loss_rate'''
    loss_df = pd.DataFrame(
        columns=['MODEL_NAME', 'game_num', 'row_loss_rate', 'col_loss_rate'])
    for i in range(0, len(game_num_list)):
        game_num = game_num_list[i]
        _, row_loss_rate = get_answer_df(
            src_dir + f"row\\{game_num - 1}.txt", True)
        _, col_loss_rate = get_answer_df(
            src_dir + f"col\\{game_num - 1}.txt", False)
        loss_df.loc[i] = [model_name, game_num, row_loss_rate, col_loss_rate]
    return loss_df


def get_choice_count_stats(game_num_list, choice_list_row, choice_list_col, src_dir):
    """得到对game_num_list中的game，LLM选择在OC, FOB, SOB中选择list中选项占总选项的比例，如nash_list是纳什均衡选择列表
        choice_list_row，choice_list_col：行玩家的选择列表，长度与game_num_list相同，表示每个game要统计的选项"""
    global_oc_cnt = 0
    global_fob_cnt = 0
    global_sob_cnt = 0
    global_total_cnt = 0

    for i in range(0, len(game_num_list)):
        game_num = game_num_list[i]
        df_row, _ = get_answer_df(
            src_dir + f"row\\{game_num - 1}.txt", True)
        df_col, _ = get_answer_df(
            src_dir + f"col\\{game_num - 1}.txt", False)
        row_oc_cnt, row_fob_cnt, row_sob_cnt, row_total_cnt = get_choice_count(
            df_row, choice_list_row[i], choice_list_col[i], True)
        col_oc_cnt, col_fob_cnt, col_sob_cnt, col_total_cnt = get_choice_count(
            df_col, choice_list_row[i], choice_list_col[i], False)
        oc_cnt = row_oc_cnt + col_oc_cnt
        fob_cnt = row_fob_cnt + col_fob_cnt
        sob_cnt = row_sob_cnt + col_sob_cnt
        total_cnt = row_total_cnt + col_total_cnt
        global_oc_cnt += oc_cnt
        global_fob_cnt += fob_cnt
        global_sob_cnt += sob_cnt
        global_total_cnt += total_cnt
    return global_oc_cnt / global_total_cnt, global_fob_cnt / global_total_cnt, global_sob_cnt / global_total_cnt


def get_summary(game_num_list, src_dir, func):
    global_spec_cnt = 0
    global_total_cnt = 0
    for i in range(0, len(game_num_list)):
        game_num = game_num_list[i]
        df_row, _ = get_answer_df(
            src_dir + f"row\\{game_num - 1}.txt", True)
        df_col, _ = get_answer_df(
            src_dir + f"col\\{game_num - 1}.txt", False)
        row_spec_cnt, row_total_cnt = func(
            df_row, rpp[game_num - 1], True)
        col_spec_cnt, col_total_cnt = func(
            df_col, cpp[game_num - 1], False)
        consistent_cnt = row_spec_cnt + col_spec_cnt
        total_cnt = row_total_cnt + col_total_cnt
        global_spec_cnt += consistent_cnt
        global_total_cnt += total_cnt
    return global_spec_cnt / global_total_cnt


# 以下几个函数都是对game_num_list中的所有game进行统计，返回汇总后的统计值
def get_fo_consistency_stats(game_num_list, src_dir):
    return get_summary(game_num_list, src_dir, get_fo_consistency)


def get_so_consistency_stats(game_num_list, src_dir):
    return get_summary(game_num_list, src_dir, get_so_consistency)


def get_max_consistency_stats(game_num_list, src_dir):
    return get_summary(game_num_list, src_dir, get_max_consistency)


def get_nash_consistency_stats(game_num_list, src_dir):
    nash_list_row = game_info_list.nash_list_row
    nash_list_col = game_info_list.nash_list_col
    global_consistent_cnt = 0
    global_total_cnt = 0
    for i in range(0, len(game_num_list)):
        game_num = game_num_list[i]
        df_row, _ = get_answer_df(
            src_dir + f"row\\{game_num - 1}.txt", True)
        df_col, _ = get_answer_df(
            src_dir + f"col\\{game_num - 1}.txt", False)
        row_consistent_cnt, row_total_cnt = get_nash_consistency(
            df_row, True, nash_list_row[i], nash_list_col[i])
        col_consistent_cnt, col_total_cnt = get_nash_consistency(
            df_col, False, nash_list_row[i], nash_list_col[i])
        consistent_cnt = row_consistent_cnt + col_consistent_cnt
        total_cnt = row_total_cnt + col_total_cnt
        global_consistent_cnt += consistent_cnt
        global_total_cnt += total_cnt
    return global_consistent_cnt / global_total_cnt


def get_type_stat(game_num_list, src_dir):
    '''统计LLM在面临二选一、三选一、四选一时选择不同选项的比例，以及面临的次数'''
    cnt_numerator = [{
        'A': 0,
        'P': 0,
        'O': 0,
        'E': 0,
        'S': 0,
        'D1': 0,
        'D2': 0,
        'L2': 0,
    } for i in range(0, 3)]
    cnt_denominator = [{
        'A': 0,
        'P': 0,
        'O': 0,
        'E': 0,
        'S': 0,
        'D1': 0,
        'D2': 0,
        'L2': 0,
    } for i in range(0, 3)]
    times_cnt = [0 for i in range(0, 3)]
    for i in range(0, len(game_num_list)):
        game_num = game_num_list[i]
        df_row, _ = get_answer_df(
            src_dir + f"row\\{game_num - 1}.txt", True)
        df_col, _ = get_answer_df(
            src_dir + f"col\\{game_num - 1}.txt", False)
        game_type_info = type_info.game_list[game_num - 1]
        # [['D1', 'D2', 'E', 'S'], ['A', 'P', 'O']]
        game_row_type_list = game_type_info.row_type_list
        # [['D'], ['A']]
        game_col_type_list = game_type_info.col_type_list
        row_type_cnt_list = get_all_choice_cnt(
            df_row, True, len(game_row_type_list))  # [0, 10]
        col_type_cnt_list = get_all_choice_cnt(
            df_col, False, len(game_col_type_list))

        # row
        for j in range(0, len(game_row_type_list)):
            game_row_type = game_row_type_list[j]
            for row_type in game_row_type:
                cnt_numerator[len(game_row_type_list) -
                              2][row_type] += row_type_cnt_list[j]
        row_choice_type_list = []
        for row_choice_types in game_row_type_list:
            for row_choice_type in row_choice_types:
                row_choice_type_list.append(row_choice_type)
        row_choice_type_list = list(set(row_choice_type_list))

        for row_choice_type in row_choice_type_list:
            cnt_denominator[len(game_row_type_list) -
                            2][row_choice_type] += sum(row_type_cnt_list)
        times_cnt[len(game_row_type_list) - 2] += 1
        # col
        for j in range(0, len(game_col_type_list)):
            game_col_type = game_col_type_list[j]
            for col_type in game_col_type:
                cnt_numerator[len(game_col_type_list) -
                              2][col_type] += col_type_cnt_list[j]
        col_choice_type_list = []
        for col_choice_types in game_col_type_list:
            for col_choice_type in col_choice_types:
                col_choice_type_list.append(col_choice_type)
        col_choice_type_list = list(set(col_choice_type_list))
        for col_choice_type in col_choice_type_list:
            cnt_denominator[len(game_col_type_list) -
                            2][col_choice_type] += sum(col_type_cnt_list)
        times_cnt[len(game_col_type_list) - 2] += 1
    df = pd.DataFrame(index=[0, 1, 2], columns=[
        'A', 'P', 'O', 'E', 'S', 'D1', 'D2', 'L2', 'times'], dtype=float)
    for i in range(0, len(cnt_numerator)):
        spec_numerator = cnt_numerator[i]
        spec_denominator = cnt_denominator[i]
        for key in spec_numerator.keys():
            try:
                df[key].iloc[i] = spec_numerator[key] / \
                    spec_denominator[key]
            except:
                df[key].iloc[i] = 0
        df['times'].iloc[i] = times_cnt[i]
    return df


def show_all_stat_for_model(model_name, result_base_dir):
    game_num_list = [1, 2, 3, 4, 5, 6, 7, 8,
                     9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
    D_game_num_list = [1, 3, 7, 9, 11, 12, 13, 16, 17, 18]
    ND_game_num_list = [2, 4, 5, 6, 8, 10, 14, 15]
    game_num_list_simp = [1, 3, 7, 9, 11, 12, 13, 16, 17, 18]
    game_num_list_norm = [2, 6, 14, 15]
    game_num_list_comp = [4, 5, 8, 10]
    nash_list_row = game_info_list.nash_list_row
    nash_list_col = game_info_list.nash_list_col
    altru_list_row = game_info_list.altru_list_row
    altru_list_col = game_info_list.altru_list_col
    D_nash_list_row = [nash_list_row[i - 1] for i in D_game_num_list]
    D_nash_list_col = [nash_list_col[i - 1] for i in D_game_num_list]
    ND_nash_list_row = [nash_list_row[i - 1] for i in ND_game_num_list]
    ND_nash_list_col = [nash_list_col[i - 1] for i in ND_game_num_list]
    D_altru_list_row = [altru_list_row[i - 1] for i in D_game_num_list]
    D_altru_list_col = [altru_list_col[i - 1] for i in D_game_num_list]
    ND_altru_list_row = [altru_list_row[i - 1] for i in ND_game_num_list]
    ND_altru_list_col = [altru_list_col[i - 1] for i in ND_game_num_list]
    src_dir = result_base_dir + model_name + "\\"
    # 统计每个game的缺失率
    loss_df = get_loss_rate(game_num_list, model_name, src_dir)

    # 分不同类型的game计算nash rate/altru rate
    oc_nash_rate_all, fo_nash_rate_all, so_nash_rate_all = get_choice_count_stats(
        game_num_list, nash_list_row, nash_list_col, src_dir)
    oc_nash_rate_D, fo_nash_rate_D, so_nash_rate_D = get_choice_count_stats(
        D_game_num_list, D_nash_list_row, D_nash_list_col, src_dir)
    oc_nash_rate_ND, fo_nash_rate_ND, so_nash_rate_ND = get_choice_count_stats(
        ND_game_num_list, ND_nash_list_row, ND_nash_list_col, src_dir)
    oc_nash_rate_simp, fo_nash_rate_simp, so_nash_rate_simp = get_choice_count_stats(
        game_num_list_simp, nash_list_row, nash_list_col, src_dir)
    oc_nash_rate_norm, fo_nash_rate_norm, so_nash_rate_norm = get_choice_count_stats(
        game_num_list_norm, nash_list_row, nash_list_col, src_dir)
    oc_nash_rate_comp, fo_nash_rate_comp, so_nash_rate_comp = get_choice_count_stats(
        game_num_list_comp, nash_list_row, nash_list_col, src_dir)
    oc_altru_rate_all, fo_altru_rate_all, so_altru_rate_all = get_choice_count_stats(
        game_num_list, altru_list_row, altru_list_col, src_dir)
    oc_altru_rate_D, fo_altru_rate_D, so_altru_rate_D = get_choice_count_stats(
        D_game_num_list, D_altru_list_row, D_altru_list_col, src_dir)
    oc_altru_rate_ND, fo_altru_rate_ND, so_altru_rate_ND = get_choice_count_stats(
        ND_game_num_list, ND_altru_list_row, ND_altru_list_col, src_dir)
    oc_altru_rate_simp, fo_altru_rate_simp, so_altru_rate_simp = get_choice_count_stats(
        game_num_list_simp, altru_list_row, altru_list_col, src_dir)
    oc_altru_rate_norm, fo_altru_rate_norm, so_altru_rate_norm = get_choice_count_stats(
        game_num_list_norm, altru_list_row, altru_list_col, src_dir)
    oc_altru_rate_comp, fo_altru_rate_comp, so_altru_rate_comp = get_choice_count_stats(
        game_num_list_comp, altru_list_row, altru_list_col, src_dir)

    stat_oc = [model_name, oc_nash_rate_all, oc_nash_rate_D, oc_nash_rate_ND, oc_altru_rate_all, oc_altru_rate_D, oc_altru_rate_ND,
               oc_nash_rate_simp, oc_nash_rate_norm, oc_nash_rate_comp, oc_altru_rate_simp, oc_altru_rate_norm, oc_altru_rate_comp]
    stat_fo = ["", fo_nash_rate_all, fo_nash_rate_D, fo_nash_rate_ND, fo_altru_rate_all, fo_altru_rate_D, fo_altru_rate_ND,
               fo_nash_rate_simp, fo_nash_rate_norm, fo_nash_rate_comp, fo_altru_rate_simp, fo_altru_rate_norm, fo_altru_rate_comp]
    stat_so = ["", so_nash_rate_all, so_nash_rate_D, so_nash_rate_ND, so_altru_rate_all, so_altru_rate_D, so_altru_rate_ND,
               so_nash_rate_simp, so_nash_rate_norm, so_nash_rate_comp, so_altru_rate_simp, so_altru_rate_norm, so_altru_rate_comp]

    new_stat_df = pd.DataFrame(columns=['MODEL_NAME', 'oc_nash_rate_all', 'oc_nash_rate_D',
                               'oc_nash_rate_ND', 'oc_altru_rate_all', 'oc_altru_rate_D', 'oc_altru_rate_ND',
                               'oc_nash_rate_simp', 'oc_nash_rate_norm', 'oc_nash_rate_comp', 
                               'oc_altru_rate_simp', 'oc_altru_rate_norm', 'oc_altru_rate_comp'])
    new_stat_df.loc[0] = stat_oc
    new_stat_df.loc[1] = stat_fo
    new_stat_df.loc[2] = stat_so

    # 分不同类型的game计算一致性
    consistent_rate = get_fo_consistency_stats(game_num_list, src_dir)
    consistent_rate_D = get_fo_consistency_stats(D_game_num_list, src_dir)
    consistent_rate_ND = get_fo_consistency_stats(ND_game_num_list, src_dir)
    consistent_rate_simp = get_fo_consistency_stats(
        game_num_list_simp, src_dir)
    consistent_rate_norm = get_fo_consistency_stats(
        game_num_list_norm, src_dir)
    consistent_rate_comp = get_fo_consistency_stats(
        game_num_list_comp, src_dir)
    so_consistent_rate = get_so_consistency_stats(game_num_list, src_dir)
    so_consistent_rate_D = get_so_consistency_stats(D_game_num_list, src_dir)
    so_consistent_rate_ND = get_so_consistency_stats(ND_game_num_list, src_dir)
    so_consistent_rate_simp = get_so_consistency_stats(
        game_num_list_simp, src_dir)
    so_consistent_rate_norm = get_so_consistency_stats(
        game_num_list_norm, src_dir)
    so_consistent_rate_comp = get_so_consistency_stats(
        game_num_list_comp, src_dir)
    max_consistent_rate = get_max_consistency_stats(game_num_list, src_dir)
    max_consistent_rate_D = get_max_consistency_stats(D_game_num_list, src_dir)
    max_consistent_rate_ND = get_max_consistency_stats(
        ND_game_num_list, src_dir)
    max_consistent_rate_simp = get_max_consistency_stats(
        game_num_list_simp, src_dir)
    max_consistent_rate_norm = get_max_consistency_stats(
        game_num_list_norm, src_dir)
    max_consistent_rate_comp = get_max_consistency_stats(
        game_num_list_comp, src_dir)
    nash_consistent_rate = get_nash_consistency_stats(game_num_list, src_dir)
    nash_consistent_rate_D = get_nash_consistency_stats(
        D_game_num_list, src_dir)
    nash_consistent_rate_ND = get_nash_consistency_stats(
        ND_game_num_list, src_dir)
    nash_consistent_rate_simp = get_nash_consistency_stats(
        game_num_list_simp, src_dir)
    nash_consistent_rate_norm = get_nash_consistency_stats(
        game_num_list_norm, src_dir)
    nash_consistent_rate_comp = get_nash_consistency_stats(
        game_num_list_comp, src_dir)

    new_rate_df = pd.DataFrame(columns=['MODEL_NAME', 'fo_consistent_rate',
                                        'so_consistent_rate', 'max_consistent_rate', 'nash_consistent_rate'])
    new_rate_df.loc[0] = [model_name, consistent_rate, so_consistent_rate,
                          max_consistent_rate, nash_consistent_rate,]
    new_rate_df.loc[1] = ["", consistent_rate_D, so_consistent_rate_D,
                          max_consistent_rate_D, nash_consistent_rate_D,]
    new_rate_df.loc[2] = ["", consistent_rate_ND, so_consistent_rate_ND,
                          max_consistent_rate_ND, nash_consistent_rate_ND,]
    new_rate_df.loc[3] = ["", consistent_rate_simp, so_consistent_rate_simp,
                          max_consistent_rate_simp, nash_consistent_rate_simp,]
    new_rate_df.loc[4] = ["", consistent_rate_norm, so_consistent_rate_norm,
                          max_consistent_rate_norm, nash_consistent_rate_norm,]
    new_rate_df.loc[5] = ["", consistent_rate_comp, so_consistent_rate_comp,
                          max_consistent_rate_comp, nash_consistent_rate_comp,]

    new_type_stat_df = get_type_stat(game_num_list, src_dir)
    new_type_stat_df['MODEL_NAME'] = model_name

    return loss_df, new_stat_df, new_rate_df, new_type_stat_df


if __name__ == '__main__':
    # result_base_dir = r"E:\Learning\ThisTerm\GraduationProject\my_project\results\prisoner_dilemma_games\\"
    # save_dir = r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics\prisoner_dilemma_games\\"
    result_base_dir = r"E:\Learning\ThisTerm\GraduationProject\my_project\results\personality\ernie-3.5-8k-0205\2\1\\"
    save_dir = r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics\personalities\\"
    
    MODEL_NAME_LIST = [
        # "chatglm3-6b",
        "ernie-3.5-8k-0205",
        # "gemma_7b_it",
        # "gpt-3.5-turbo",
        # "gpt-4",
        # "llama_3_8b",
        # "llama_3_70b",
        # "qwen-plus",
        # "qwen-turbo",
        # "xuanyuan_70b_chat",
    ]
    for model_name in MODEL_NAME_LIST:
        print("Calculating data: ", model_name)
        new_loss_df, new_stat_df, new_rate_df, new_type_stat_df = show_all_stat_for_model(
            model_name, result_base_dir)
        if model_name == MODEL_NAME_LIST[0]:
            loss_df = new_loss_df
            stat_df = new_stat_df
            rate_df = new_rate_df
            type_stat_df = new_type_stat_df
        else:
            loss_df = pd.concat([loss_df, new_loss_df], ignore_index=True)
            stat_df = pd.concat([stat_df, new_stat_df], ignore_index=True)
            rate_df = pd.concat([rate_df, new_rate_df], ignore_index=True)
            type_stat_df = pd.concat(
                [type_stat_df, new_type_stat_df], ignore_index=True)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    # loss_df的row_loss_rate和col_loss_rate计算均值
    loss_df.to_csv(save_dir + "loss_original.csv", index=False)
    loss_df = loss_df.groupby('MODEL_NAME').mean().reset_index()
    loss_df = loss_df.drop(columns=['game_num'])
    loss_df.to_csv(save_dir + "loss.csv", index=False)
    print(loss_df)
    print(stat_df)
    print(rate_df)
    print(type_stat_df)
    
    stat_df.to_csv(save_dir + "stat.csv", index=False)
    rate_df.to_csv(save_dir + "rate.csv", index=False)
    type_stat_df.to_csv(save_dir + "type.csv", index=False)
    loss_df.to_csv(save_dir + "loss.csv", index=False)
