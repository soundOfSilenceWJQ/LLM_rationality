import os

import pandas as pd


def count_ab(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines()
    choices = []
    for l in range(1, len(lines)):
        line = lines[l]
        # # 找到每行出现的第一个A或B
        # for i in range(len(line)):
        #     if line[i] == "A" or line[i] == "B":
        #         break
        # 找到每行出现的第一个“背叛”或“合作”
        for i in range(len(line)):
            if (line[i] == "合" and line[i + 1] == "作"):
                choices.append('A')
                break
            if (line[i] == "背" and line[i + 1] == "叛"):
                choices.append('B')
                break
        
    count_a = choices.count("A")
    count_b = choices.count("B")
    return count_a, count_b
        


if __name__ == '__main__':
    # 读取文件
    model_list = os.listdir("E:\Learning\ThisTerm\GraduationProject\my_project\\results\\prisoner_dilemma3\\")
    df = pd.DataFrame(columns=["count_a", "count_b", "other"])
    
    for model in model_list:
        model_dir = "E:\Learning\ThisTerm\GraduationProject\my_project\\results\\prisoner_dilemma3\\" + model + "\\"
        file_list = os.listdir(model_dir)
        for file in file_list:
            file_path = model_dir + file
            count_a, count_b = count_ab(file_path)
            print(model, file, count_a, count_b)
        df.loc[model] = [count_a, count_b, 30-count_a-count_b]
    df.to_csv("E:\Learning\ThisTerm\GraduationProject\my_project\\results\statistics_summary\\count3.csv", index=True)