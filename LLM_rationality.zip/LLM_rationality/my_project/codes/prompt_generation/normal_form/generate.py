import os

import payoff_matrix


def matrix2str(matrix_row, matrix_col, row_or_col, language="zh"):
    '''# row_or_col表示玩家是行玩家(True)还是列玩家(False)'''
    lower_case_letters = [chr(i) for i in range(97, 123)]
    upper_case_letters = [chr(i) for i in range(65, 91)]
    choice_num_row = len(matrix_row)
    choice_num_col = len(matrix_row[0])
    if language == "zh":
        if row_or_col:
            pd_prompt_zh = "假设你和另一个你不认识的人（正常成年人，有一定的选择判断能力），你们之间没有任何交流的机会。\n你有{choice_num_row}种选择，而对方有{choice_num_col}种选择。\n"\
                .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_zh += "你的选择有：{row_choices}\n对方的选择有：{col_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):
                for j in range(choice_num_col):
                    pd_prompt_zh += "如果你选择{row_choice}，而对方选择{col_choice}，你将获得{payoff_row}美元，对方将获得{payoff_col}美元。\n"\
                    .format(row_choice=upper_case_letters[i], col_choice=lower_case_letters[j], payoff_row=matrix_row[i][j], payoff_col=matrix_col[i][j])
            pd_prompt_zh += "你们双方各自同时做出选择，得到各自的奖励之后游戏结束。\n依次回答以下3个问题：\n1.你认为，对方会认为你的选择是什么？（从{row_choices}中选择）\n2.你认为对方的选择是什么？（从{col_choices}中选择）\n3.你的选择是什么？（从{row_choices}中选择）\n".format(col_choices=lower_case_letters[:choice_num_col], row_choices=upper_case_letters[:choice_num_row])

        else:
            pd_prompt_zh = "假设你和另一个你不认识的人需要同时分别做出选择，你们之间没有任何交流的机会。\n你有{choice_num_col}种选择，而对方有{choice_num_row}种选择。\n"\
            .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_zh += "你的选择有：{col_choices}\n对方的选择有：{row_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):    
                for j in range(choice_num_col):
                    pd_prompt_zh += "如果对方选择{row_choice}，而你选择{col_choice}，对方将获得{payoff_row}美元，你将获得{payoff_col}美元。\n"\
                    .format(col_choice=lower_case_letters[j], row_choice=upper_case_letters[i], payoff_row=matrix_row[i][j], payoff_col=matrix_col[i][j])
            pd_prompt_zh += "你们双方各自同时做出选择，得到各自的奖励之后游戏结束。\n依次回答以下3个问题：\n1.你认为，对方会认为你的选择是什么？（从{col_choices}中选择）\n2.你认为对方的选择是什么？（从{row_choices}中选择）\n3.你的选择是什么？（从{col_choices}中选择）\n".format(col_choices=lower_case_letters[:choice_num_col], row_choices=upper_case_letters[:choice_num_row])
        pd_prompt_zh += "请在1000字以内给出你对于这3个问题的分析，并确保条理清晰，要点突出。  \n 最后，请在新的一行中直接给出你对于上述3个问题的答案，只用回答字母。  \n以下是回答的样例：\n对于问题1的分析：\n...\n对于问题2的分析：\n...\n对于问题3的分析：\n...\n答案：\n1. ... \n2. ... \n3. ...\n"
        return pd_prompt_zh


def prompt_gen_normal_form(save_dir, rpp, cpp, language, row_or_col=True):
    # 用于normal form game的测试
    save_dir += "row\\" if row_or_col else "col\\"
    
    if language == "zh":
        prompt_list_zh = []
        for i in range (0, 18):
            prompt_list_zh.append(matrix2str(rpp[i], cpp[i], row_or_col, language))
        prompt_list = prompt_list_zh
    elif language == "en":
        prompt_list_en = []
        for i in range (0, 18):
            prompt_list_en.append(matrix2str(rpp[i], cpp[i], row_or_col, language))
        prompt_list = prompt_list_en
    # 将生成的prompt写入文件
    # 没有文件夹则创建文件夹
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    for i in range(0, 18):
        with open(save_dir + str(i) + ".txt", "a", encoding="utf-8") as f:
            f.write(prompt_list[i])
    return prompt_list


if __name__ == '__main__':
    prompt_gen_normal_form(r"E:\Learning\ThisTerm\GraduationProject\my_project\prompt_repo\2\1\\", payoff_matrix.rpp, payoff_matrix.cpp, "zh", True)
    prompt_gen_normal_form(r"E:\Learning\ThisTerm\GraduationProject\my_project\prompt_repo\2\1\\", payoff_matrix.rpp, payoff_matrix.cpp, "zh", False)