lower_case_letters = [chr(i) for i in range(97, 123)]
upper_case_letters = [chr(i) for i in range(65, 91)]

def matrix2str(matrix_row, matrix_col, row_or_col, lang="zh"):
    # row_or_col表示玩家是行玩家(True)还是列玩家(False)
    choice_num_row = len(matrix_row)
    choice_num_col = len(matrix_row[0])
    if lang == "zh":
        if row_or_col:
            pd_prompt_zh = "假设你和另一个你不认识的人（正常成年人，有一定的选择判断能力）需要一起玩一个游戏，你们之间没有任何交流的机会。\n你有{choice_num_row}种选择，而对方有{choice_num_col}种选择。\n"\
                .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_zh += "你的选择有：{row_choices}\n对方的选择有：{col_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):
                for j in range(choice_num_col):
                    pd_prompt_zh += "如果你选择{row_choice}，而对方选择{col_choice}，你将获得{payoff_row}美元，对方将获得{payoff_col}美元。\n"\
                    .format(row_choice=upper_case_letters[i], col_choice=lower_case_letters[j], payoff_row=matrix_row[i][j], payoff_col=matrix_col[i][j])
            pd_prompt_zh += "你们双方各自同时做出选择，得到各自的奖励之后游戏结束。\n依次回答以下3个问题：\n1.你认为，对方会认为你的选择是什么？（从{row_choices}中选择）\n2.你认为对方的选择是什么？（从{col_choices}中选择）\n3.你的选择是什么？（从{row_choices}中选择）\n".format(col_choices=lower_case_letters[:choice_num_col], row_choices=upper_case_letters[:choice_num_row])

        else:
            pd_prompt_zh = "假设你和另一个你不认识的人需要同时分别做出选择，你们之间没有任何交流的机会。\n你有{choice_num_col}种选择，而对方有{choice_num_row}种选择。\n"\
            .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_zh += "你的选择有：{col_choices}\n对方的选择有：{row_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):    
                for j in range(choice_num_col):
                    pd_prompt_zh += "如果对方选择{row_choice}，而你选择{col_choice}，对方将获得{payoff_row}美元，你将获得{payoff_col}美元。\n"\
                    .format(col_choice=lower_case_letters[j], row_choice=upper_case_letters[i], payoff_row=matrix_row[i][j], payoff_col=matrix_col[i][j])
            pd_prompt_zh += "你们双方各自同时做出选择，得到各自的奖励之后游戏结束。\n依次回答以下3个问题：\n1.你认为，对方会认为你的选择是什么？（从{col_choices}中选择）\n2.你认为对方的选择是什么？（从{row_choices}中选择）\n3.你的选择是什么？（从{col_choices}中选择）\n".format(col_choices=lower_case_letters[:choice_num_col], row_choices=upper_case_letters[:choice_num_row])
        return pd_prompt_zh
    elif lang == "en":
        if row_or_col:
            pd_prompt_en = "Suppose you and another person you don't know (an adult with a certain level of decision-making ability) need to play a game together, and you have no chance to communicate with each other.\nYou have {choice_num_row} choices, and the other person has {choice_num_col} choices.\n"\
                .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_en += "Your choices are: {row_choices}\nThe other person's choices are: {col_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):
                for j in range(choice_num_col):
                    pd_prompt_en += "If you choose option {row_choice} and the other person chooses option {col_choice}, you will receive ${payoff_row}, and the other person will receive ${payoff_col}.\n"\
                    .format(row_choice=upper_case_letters[i], col_choice=lower_case_letters[j], payoff_row=matrix_row[i][j], payoff_col=matrix_col[i][j])
        else:
            pd_prompt_en = "Suppose you and another person you don't know need to make choices simultaneously, and you have no chance to communicate with each other.\nYou have {choice_num_col} choices, and the other person has {choice_num_row} choices.\n"\
            .format(choice_num_row=choice_num_row, choice_num_col=choice_num_col)
            pd_prompt_en += "Your choices are: {col_choices}\nThe other person's choices are: {row_choices}\n".format(row_choices=upper_case_letters[:choice_num_row], col_choices=lower_case_letters[:choice_num_col])
            for i in range(choice_num_row):    
                for j in range(choice_num_col):
                    pd_prompt_en += "If the other person chooses option {row_choice} and you choose option {col_choice}, the other person will receive ${payoff_row}, and you will receive ${payoff_col}.\n"\
                    .format(col_choice=lower_case_letters[j], row_choice=upper_case_letters[i], payoff_col=matrix_col[i][j], payoff_row=matrix_row[i][j])
        pd_prompt_en += "You and the other person make choices simultaneously, and the game ends after both of you receive your rewards.\nAnswer these following 3 questions: 1. What is your choice?\n2. What do you think the other person's choice is?\n3. What do you think the other person thinks your choice is? \nPlease answer in the following format: [Answer to question 1][space][Answer to question 2][space][Answer to question 3]\n"
        return pd_prompt_en


if __name__ == "__main__":
    import column_player_payoffs
    import my_project.codes.prompt_generation.normal_form.payoff_matrix as payoff_matrix
    game_num = 10

    print(matrix2str(payoff_matrix.rpp[game_num], column_player_payoffs.cpp[game_num], True, "zh"))
    print("\n")
    print(matrix2str(payoff_matrix.rpp[game_num], column_player_payoffs.cpp[game_num], False, "zh"))