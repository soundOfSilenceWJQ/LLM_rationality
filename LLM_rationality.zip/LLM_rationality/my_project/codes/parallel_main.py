from concurrent.futures import ThreadPoolExecutor
import os
from processor import ErnieProcessor, GPTProcessor, QwenProcessor
from utils import beautify, read_txt, traverse_folder
from config import modelConfigErnie, modelConfigGPT, modelConfigQwen, testConfig


def test_the_prompt(my_processor, prompt, test_times, dir_name, file_name, save_result):
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
    my_processor.write_to_json(prompt, dir_name + file_name)
    with ThreadPoolExecutor(max_workers=32) as executor:
        for i in range(test_times):
            executor.submit(my_processor.start_multi_thread,
                            prompt, dir_name + file_name, save_result)


def prompt_gen(prompt_paths):
    prompt_list = []
    for prompt_path in prompt_paths:
        lines = read_txt(prompt_path)
        prompt_list.append(lines)
    return prompt_list


def file_path_constructor(save_dir, sub_file_path):
    if "\\" not in sub_file_path:
        return save_dir, sub_file_path
    file_name = sub_file_path[sub_file_path.rfind("\\") + 1:]
    sub_file_path = sub_file_path[:sub_file_path.rfind("\\")]
    save_dir += sub_file_path + "\\"
    return save_dir, file_name


def test_model(test_processor, prompt_repo_path, test_config, model_config, save_result=True):

    save_dir = test_config.save_dir + model_config.model + "\\"

    prompt_paths = traverse_folder(prompt_repo_path)
    sub_prompt_paths = [prompt_path[len(prompt_repo_path):]
                        for prompt_path in prompt_paths]
    prompt_list = prompt_gen(prompt_paths)
    
    # 替换提示词模板中的变量
    for i in range(0, len(prompt_list)):
        prompt = prompt_list[i]
        # 独裁者博弈
        prompt = prompt.replace(r"{money}", str(100))
        prompt = prompt.replace(r"{M}", str(100))
        # 囚徒困境博弈
        prompt = prompt.replace(r"{a_a_1}", str(2))
        prompt = prompt.replace(r"{b_b_1}", str(3))
        prompt = prompt.replace(r"{a_b_1}", str(4))
        prompt = prompt.replace(r"{b_a_1}", str(1))
        # 囚徒困境博弈
        prompt = prompt.replace(r"{a_a_2}", str(75))
        prompt = prompt.replace(r"{b_b_2}", str(50))
        prompt = prompt.replace(r"{a_b_2}", str(25))
        prompt = prompt.replace(r"{b_a_2}", str(100))
        # 银行家博弈
        prompt = prompt.replace(r"{money}", str(100))
        prompt = prompt.replace(r"{times}", str(3))
        prompt = prompt.replace(r"{M}", str(100))
        
        prompt_list[i] = prompt

    for i in range(0, len(prompt_list)):
        prompt = prompt_list[i]
        print("Testing: " + prompt_paths[i] + "...")

        answer_file_dir, answer_file_name = file_path_constructor(
            save_dir, sub_prompt_paths[i])
        print("answer_file_dir: ", answer_file_dir)
        print("answer_file_name: ", answer_file_name)

        if os.path.exists(answer_file_dir + answer_file_name):
            print("Already exists: ", answer_file_dir + answer_file_name)
            continue
        test_the_prompt(test_processor, prompt, test_config.test_times,
                            answer_file_dir, answer_file_name, save_result)
        # if testConfig.reason_needed == True:
        #     beautify(answer_file_dir + answer_file_name)


if __name__ == '__main__':
    test_config = testConfig()
    test_processor_list = [
        ErnieProcessor(modelConfigErnie('ernie-3.5-8k-0205')),
        ErnieProcessor(modelConfigErnie('gemma_7b_it')),
        # ErnieProcessor(modelConfigErnie('llama_2_13b')),
        # ErnieProcessor(modelConfigErnie('llama_2_70b')),
        # ErnieProcessor(modelConfigErnie('llama_3_8b')),
        # ErnieProcessor(modelConfigErnie('llama_3_70b')),
        ErnieProcessor(modelConfigErnie('chatglm2_6b_32k')),
        ErnieProcessor(
            modelConfigErnie('xuanyuan_70b_chat')),
        ErnieProcessor(modelConfigErnie('yi_34b_chat')),
        QwenProcessor(modelConfigQwen('qwen-turbo')),
        QwenProcessor(modelConfigQwen('qwen-plus')),
        QwenProcessor(modelConfigQwen('chatglm3-6b')),
        # GPTProcessor(modelConfigGPT('gpt-4')),
        # GPTProcessor(modelConfigGPT('gpt-3.5-turbo')),
    ]
    model_config_list = [
        modelConfigErnie('ernie-3.5-8k-0205'),
        modelConfigErnie('gemma_7b_it'),
        # modelConfigErnie('llama_2_13b'),
        # modelConfigErnie('llama_2_70b'),
        # modelConfigErnie('llama_3_8b'),
        # modelConfigErnie('llama_3_70b'),
        modelConfigErnie('chatglm2_6b_32k'),
        modelConfigErnie('xuanyuan_70b_chat'),
        modelConfigErnie('yi_34b_chat'),
        modelConfigQwen('qwen-turbo'),
        modelConfigQwen('qwen-plus'),
        modelConfigQwen('chatglm3-6b'),
        # modelConfigGPT('gpt-4'),
        # modelConfigGPT('gpt-3.5-turbo'),
    ]
    prompt_repo_path = test_config.prompt_repo_path
    for i in range(0, len(test_processor_list)):
        print("Testing model: ", model_config_list[i].model)
        test_model(test_processor_list[i], prompt_repo_path, test_config, model_config_list[i], True)
