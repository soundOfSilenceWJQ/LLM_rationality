import os
import re
import time
import matplotlib.pyplot as plt

from matplotlib.ticker import PercentFormatter
import pandas as pd

def read_txt(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        return ''.join(lines)
    

def traverse_folder(directory):
    # 获取目录下的所有文件及文件夹
    file_path_list = []
    items = os.listdir(directory)
    
    for item in items:
        # 拼接路径
        item_path = os.path.join(directory, item)
        
        # 如果是文件夹，则递归调用traverse_folder函数
        if os.path.isdir(item_path):
            sub_file_path_list = traverse_folder(item_path)
            file_path_list.extend(sub_file_path_list)
        else:
            file_path_list.append(item_path)
    return file_path_list


def concat_csv(file_path_list):
    dfs = []
    for file_path in file_path_list:
        df = pd.read_csv(file_path)
        dfs.append(df)
    return pd.concat(dfs, ignore_index=True, axis=0)


def sum_stat(root_dir_path, file_name, save_file_path):
    # print(traverse_folder(r"E:\Learning\ThisTerm\GraduationProject\my_project\prompt_repo\1\\"))
    sub_list = os.listdir(root_dir_path)
    file_path_list = []
    for sub in sub_list:
        dir_path = os.path.join(root_dir_path, sub)
        file_path = os.path.join(dir_path, file_name)
        file_path_list.append(file_path)
    concat_csv(file_path_list).to_csv(save_file_path, index=False)


def beautify(file_path, new_file_path=None):
    # 给文件的每一行加上行号，数字左右加上大括号，格式更好看
    if new_file_path is None:
        new_file_path = file_path
    with open(file_path, 'r') as file:
        lines = file.readlines()
    # 找到lines中任意长度的数字，并在左右加上大括号
    for i in range(0, len(lines)):
        line = lines[i]
        line = re.sub(r'(\d+)(\.\d+)?', r'{\1}\2', line)
        lines[i] = line
    numbered_lines = [f"({i}) {line}" for i, line in enumerate(lines)]
    formatted_text = '\n'.join(numbered_lines)
    formatted_text = formatted_text.replace('\\n', '\n')


    with open(new_file_path, 'w') as file:
        file.write(formatted_text)


if __name__ == '__main__':
    # sum_stat(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics\prisoner_dilemma_games\\", "rate.csv", r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics_summary\rate_all.csv")
    sum_stat(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics\prisoner_dilemma_games\\", "stat.csv", 
             r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics_summary\stat_all2.csv")
    # sum_stat(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics\prisoner_dilemma_games\\", "type.csv", r"E:\Learning\ThisTerm\GraduationProject\my_project\results\statistics_summary\type_all.csv")
    # beautify(r"E:\Learning\ThisTerm\GraduationProject\my_project\results\dictator_games\ernie-char-8k\1\1.txt", 
    #          r"E:\Learning\ThisTerm\GraduationProject\my_project\results\dictator_games\ernie-char-8k\1\1_beautified.txt")